<template>
  <MainLayout>
    <div class="bg-gradient-to-b from-blue-100 to-white">
      <main class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div class="text-center mb-16">
          <h2 class="text-4xl font-extrabold text-gray-900 sm:text-5xl sm:tracking-tight lg:text-6xl">Bienvenido a la Comunidad Odontológica</h2>
          <p class="mt-5 max-w-xl mx-auto text-xl text-gray-500">La plataforma profesional para conectar con colegas, compartir conocimientos y mejorar tu práctica odontológica.</p>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-3 gap-8 mt-12">
          <div class="bg-white p-6 rounded-lg shadow-md">
            <div class="text-blue-500 text-4xl mb-4">
              <i class="fas fa-users"></i>
            </div>
            <h3 class="text-xl font-bold mb-2">Comunidad Profesional</h3>
            <p class="text-gray-600">Conecta con odontólogos de todo el mundo, comparte experiencias y amplía tu red profesional.</p>
          </div>

          <div class="bg-white p-6 rounded-lg shadow-md">
            <div class="text-blue-500 text-4xl mb-4">
              <i class="fas fa-graduation-cap"></i>
            </div>
            <h3 class="text-xl font-bold mb-2">Recursos Educativos</h3>
            <p class="text-gray-600">Accede a materiales formativos, casos clínicos y las últimas innovaciones en el campo de la odontología.</p>
          </div>

          <div class="bg-white p-6 rounded-lg shadow-md">
            <div class="text-blue-500 text-4xl mb-4">
              <i class="fas fa-comments"></i>
            </div>
            <h3 class="text-xl font-bold mb-2">Foros Especializados</h3>
            <p class="text-gray-600">Participa en discusiones sobre especialidades, técnicas y soluciones a desafíos clínicos.</p>
          </div>
        </div>
      </main>
    </div>
  </MainLayout>
</template>

<script lang="ts">
import { defineComponent } from 'vue'
import MainLayout from '@/layouts/MainLayout.vue'

export default defineComponent({
  name: 'HomePage',
  components: {
    MainLayout
  }
})
</script>
