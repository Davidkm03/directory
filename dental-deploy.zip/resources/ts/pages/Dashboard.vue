<template>
  <div class="min-h-screen bg-gray-100">
    <nav class="bg-white border-b border-gray-200">
      <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="flex justify-between h-16">
          <div class="flex">
            <div class="flex-shrink-0 flex items-center">
              <h1 class="text-xl font-bold text-blue-800">Comunidad Odontológica</h1>
            </div>
            <div class="hidden sm:-my-px sm:ml-6 sm:flex sm:space-x-8">
              <a href="#" class="border-blue-500 text-gray-900 inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium">
                Dashboard
              </a>
              <a href="#" class="border-transparent text-gray-500 hover:border-gray-300 hover:text-gray-700 inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium">
                Comunidad
              </a>
              <a href="#" class="border-transparent text-gray-500 hover:border-gray-300 hover:text-gray-700 inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium">
                Recursos
              </a>
              <a href="#" class="border-transparent text-gray-500 hover:border-gray-300 hover:text-gray-700 inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium">
                Foros
              </a>
            </div>
          </div>
          <div class="hidden sm:ml-6 sm:flex sm:items-center">
            <div class="ml-3 relative">
              <div>
                <button 
                  @click="showUserMenu = !showUserMenu"
                  class="max-w-xs bg-white flex items-center text-sm rounded-full focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                  <span class="sr-only">Abrir menú de usuario</span>
                  <img class="h-8 w-8 rounded-full" src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80" alt="" />
                </button>
              </div>
              <div 
                v-if="showUserMenu"
                class="origin-top-right absolute right-0 mt-2 w-48 rounded-md shadow-lg py-1 bg-white ring-1 ring-black ring-opacity-5 focus:outline-none"
                role="menu" 
                aria-orientation="vertical" 
                aria-labelledby="user-menu-button" 
                tabindex="-1">
                <a href="#" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100" role="menuitem">Mi perfil</a>
                <a href="#" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100" role="menuitem">Configuración</a>
                <a href="#" 
                   @click.prevent="logout"
                   class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100" 
                   role="menuitem">Cerrar sesión</a>
              </div>
            </div>
          </div>
          <div class="-mr-2 flex items-center sm:hidden">
            <button 
              @click="showMobileMenu = !showMobileMenu"
              class="bg-white inline-flex items-center justify-center p-2 rounded-md text-gray-400 hover:text-gray-500 hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
              <span class="sr-only">Abrir menú principal</span>
              <svg class="h-6 w-6" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16" />
              </svg>
            </button>
          </div>
        </div>
      </div>

      <div v-if="showMobileMenu" class="sm:hidden">
        <div class="pt-2 pb-3 space-y-1">
          <a href="#" class="bg-blue-50 border-blue-500 text-blue-700 block pl-3 pr-4 py-2 border-l-4 text-base font-medium">
            Dashboard
          </a>
          <a href="#" class="border-transparent text-gray-600 hover:bg-gray-50 hover:border-gray-300 hover:text-gray-800 block pl-3 pr-4 py-2 border-l-4 text-base font-medium">
            Comunidad
          </a>
          <a href="#" class="border-transparent text-gray-600 hover:bg-gray-50 hover:border-gray-300 hover:text-gray-800 block pl-3 pr-4 py-2 border-l-4 text-base font-medium">
            Recursos
          </a>
          <a href="#" class="border-transparent text-gray-600 hover:bg-gray-50 hover:border-gray-300 hover:text-gray-800 block pl-3 pr-4 py-2 border-l-4 text-base font-medium">
            Foros
          </a>
        </div>
        <div class="pt-4 pb-3 border-t border-gray-200">
          <div class="flex items-center px-4">
            <div class="flex-shrink-0">
              <img class="h-10 w-10 rounded-full" src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80" alt="" />
            </div>
            <div class="ml-3">
              <div class="text-base font-medium text-gray-800">Dr. Ejemplo</div>
              <div class="text-sm font-medium text-gray-500">ejemplo@dental.com</div>
            </div>
          </div>
          <div class="mt-3 space-y-1">
            <a href="#" class="block px-4 py-2 text-base font-medium text-gray-500 hover:text-gray-800 hover:bg-gray-100">
              Mi perfil
            </a>
            <a href="#" class="block px-4 py-2 text-base font-medium text-gray-500 hover:text-gray-800 hover:bg-gray-100">
              Configuración
            </a>
            <a href="#" 
               @click.prevent="logout"
               class="block px-4 py-2 text-base font-medium text-gray-500 hover:text-gray-800 hover:bg-gray-100">
              Cerrar sesión
            </a>
          </div>
        </div>
      </div>
    </nav>

    <div class="py-10">
      <header>
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h1 class="text-3xl font-bold leading-tight text-gray-900">Dashboard</h1>
        </div>
      </header>
      <main>
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
          <div class="px-4 py-8 sm:px-0">
            <div class="border-4 border-dashed border-gray-200 rounded-lg p-6">
              <h2 class="text-lg font-medium mb-4">Bienvenido a la Comunidad Odontológica</h2>
              <p>Esta es tu área personal donde podrás gestionar tu perfil y acceder a todas las funcionalidades de la plataforma.</p>
              
              <div class="mt-8 grid grid-cols-1 gap-4 sm:grid-cols-2">
                <div class="bg-white overflow-hidden shadow rounded-lg">
                  <div class="px-4 py-5 sm:p-6">
                    <h3 class="text-lg font-medium text-gray-900">Actividad reciente</h3>
                    <div class="mt-4 text-sm text-gray-500">
                      <p>No hay actividad reciente.</p>
                    </div>
                  </div>
                </div>

                <div class="bg-white overflow-hidden shadow rounded-lg">
                  <div class="px-4 py-5 sm:p-6">
                    <h3 class="text-lg font-medium text-gray-900">Próximos eventos</h3>
                    <div class="mt-4 text-sm text-gray-500">
                      <p>No hay eventos próximos.</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  </div>
</template>

<script lang="ts">
import { defineComponent, ref, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { useAuthStore } from '@/stores/auth'
import axios from 'axios'

export default defineComponent({
  name: 'DashboardPage',
  setup() {
    const router = useRouter()
    const authStore = useAuthStore()
    const showMobileMenu = ref(false)
    const showUserMenu = ref(false)
    
    // Redirigir al usuario según su rol
    const redirectBasedOnRole = async () => {
      // Si no tenemos información de usuario, intentamos obtenerla
      if (!authStore.user) {
        try {
          await authStore.getCurrentUser();
        } catch (error) {
          console.error('Error al obtener datos del usuario:', error);
          return; // Si no podemos obtener el usuario, no redirigimos
        }
      }
      
      // Redirigir según el rol
      if (authStore.user) {
        const role = authStore.user.role;
        
        switch(role) {
          case 'admin':
            router.replace({ name: 'admin' });
            break;
          case 'dentist':
            router.replace({ name: 'dentist' });
            break;
          case 'patient':
            router.replace({ name: 'patient' });
            break;
          default:
            // Si no tiene un rol válido, se queda en el dashboard
            console.warn('Usuario sin rol definido');
        }
      }
    };

    // Ejecutar la redirección cuando el componente se monte
    onMounted(() => {
      redirectBasedOnRole();
    });

    const logout = async () => {
      try {
        await axios.post('/api/logout')
        authStore.clearAuth()
        router.push({ name: 'login' })
      } catch (error) {
        console.error('Error during logout:', error)
        // Logout anyway on client side
        authStore.clearAuth()
        router.push({ name: 'login' })
      }
    }

    return {
      user: authStore.user,
      showMobileMenu,
      showUserMenu,
      logout
    }
  }
})
</script>
