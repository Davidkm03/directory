<template>
  <div class="container mx-auto px-4 py-8">
    <!-- Botón de regreso -->
    <div class="mb-6">
      <button 
        @click="$router.back()" 
        class="flex items-center text-gray-600 hover:text-teal-600"
      >
        <svg class="w-5 h-5 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18" />
        </svg>
        Volver al directorio
      </button>
    </div>
    
    <!-- Cargando -->
    <div v-if="loading" class="flex justify-center items-center py-20">
      <div class="inline-block animate-spin rounded-full h-12 w-12 border-4 border-teal-500 border-t-transparent"></div>
    </div>
    
    <!-- Error -->
    <div v-else-if="error" class="bg-white rounded-lg shadow-lg p-8">
      <div class="text-red-500 text-center">
        <svg class="w-16 h-16 mx-auto mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
        </svg>
        <p class="text-xl mb-4">{{ error }}</p>
        <button 
          @click="loadDentistProfile()" 
          class="px-6 py-2 bg-teal-600 text-white rounded-md hover:bg-teal-700"
        >
          Reintentar
        </button>
      </div>
    </div>
    
    <!-- Perfil de dentista -->
    <div v-else-if="dentist" class="bg-white rounded-lg shadow-lg overflow-hidden">
      <!-- Portada y foto de perfil -->
      <div class="h-48 bg-gradient-to-r from-teal-500 to-blue-500 relative">
        <img
          v-if="dentist.cover_image"
          :src="dentist.cover_image"
          alt="Portada"
          class="w-full h-full object-cover"
        />
        
        <!-- Botón de favorito (solo para usuarios autenticados) -->
        <button
          v-if="isAuthenticated"
          @click="toggleFavorite"
          :disabled="favoriteLoading"
          class="absolute top-4 right-4 p-2 rounded-full bg-white shadow-md hover:bg-gray-100"
        >
          <svg
            class="w-6 h-6"
            :class="isFavorite ? 'text-red-500 fill-current' : 'text-gray-400'"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
          >
            <path
              stroke-linecap="round"
              stroke-linejoin="round"
              stroke-width="2"
              d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z"
            ></path>
          </svg>
        </button>
        
        <div class="absolute -bottom-16 left-8">
          <div class="h-32 w-32 rounded-full border-4 border-white shadow-md overflow-hidden bg-white">
            <img
              :src="dentist.profile_image || '/images/default-profile.jpg'"
              :alt="dentist.user?.name"
              class="h-full w-full object-cover"
              @error="handleImageError"
            />
          </div>
        </div>
      </div>
      
      <!-- Información principal -->
      <div class="pt-20 px-8 pb-8">
        <div class="flex flex-wrap items-start justify-between">
          <div>
            <h1 class="text-3xl font-bold text-gray-900">{{ dentist.user?.name }}</h1>
            <p class="text-lg text-gray-600 mt-1" v-if="dentist.specialty">{{ dentist.specialty }}</p>
            
            <!-- Calificación -->
            <div class="flex items-center mt-2">
              <div class="flex">
                <template v-for="i in 5" :key="i">
                  <svg
                    class="w-5 h-5"
                    :class="i <= Math.round(dentist.rating || 0) ? 'text-yellow-400' : 'text-gray-300'"
                    fill="currentColor"
                    viewBox="0 0 20 20"
                  >
                    <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"></path>
                  </svg>
                </template>
              </div>
              <span class="ml-2 text-gray-600">
                {{ dentist.rating ? dentist.rating.toFixed(1) + ' de 5' : 'Sin calificaciones' }}
              </span>
            </div>
          </div>
          
          <!-- Badge de verificación -->
          <div v-if="dentist.verification_status === 'approved'" class="px-4 py-2 bg-teal-100 text-teal-800 rounded-full flex items-center">
            <svg class="w-5 h-5 mr-1" fill="currentColor" viewBox="0 0 20 20">
              <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"></path>
            </svg>
            Verificado
          </div>
        </div>
        
        <!-- Tarjetas de información -->
        <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mt-8">
          <!-- Información de contacto -->
          <div class="bg-gray-50 rounded-lg p-6">
            <h2 class="text-xl font-semibold text-gray-900 mb-4">Información de contacto</h2>
            
            <div class="space-y-4">
              <!-- Ubicación -->
              <div class="flex items-start">
                <svg class="w-5 h-5 text-teal-600 mt-1 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"></path>
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"></path>
                </svg>
                <div>
                  <p class="text-gray-700">{{ dentist.office_address }}</p>
                  <p class="text-gray-700">{{ dentist.city }}, {{ dentist.state }} {{ dentist.postal_code }}</p>
                </div>
              </div>
              
              <!-- Teléfono -->
              <div class="flex items-center">
                <svg class="w-5 h-5 text-teal-600 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"></path>
                </svg>
                <a :href="`tel:${dentist.phone_number}`" class="text-teal-600 hover:underline">{{ dentist.phone_number }}</a>
              </div>
              
              <!-- Sitio web -->
              <div class="flex items-center" v-if="dentist.website_url">
                <svg class="w-5 h-5 text-teal-600 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 12a9 9 0 01-9 9m9-9a9 9 0 00-9-9m9 9H3m9 9a9 9 0 01-9-9m9 9c1.657 0 3-4.03 3-9s-1.343-9-3-9m0 18c-1.657 0-3-4.03-3-9s1.343-9 3-9m-9 9a9 9 0 019-9"></path>
                </svg>
                <a :href="dentist.website_url" target="_blank" rel="noopener noreferrer" class="text-teal-600 hover:underline">Visitar sitio web</a>
              </div>
              
              <!-- Redes sociales -->
              <div v-if="dentist.social_media && Object.keys(dentist.social_media).length > 0" class="flex items-start">
                <svg class="w-5 h-5 text-teal-600 mt-1 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                </svg>
                <div class="flex space-x-3">
                  <a 
                    v-for="(url, platform) in dentist.social_media" 
                    :key="platform" 
                    :href="url" 
                    target="_blank" 
                    rel="noopener noreferrer"
                    class="text-gray-600 hover:text-teal-600"
                  >
                    <component :is="getSocialIcon(platform)" class="w-6 h-6" />
                  </a>
                </div>
              </div>
            </div>
          </div>
          
          <!-- Formación y experiencia -->
          <div class="bg-gray-50 rounded-lg p-6">
            <h2 class="text-xl font-semibold text-gray-900 mb-4">Formación y experiencia</h2>
            
            <div class="space-y-4">
              <!-- Educación -->
              <div class="flex items-start" v-if="dentist.university">
                <svg class="w-5 h-5 text-teal-600 mt-1 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path d="M12 14l9-5-9-5-9 5 9 5z"></path>
                  <path d="M12 14l6.16-3.422a12.083 12.083 0 01.665 6.479A11.952 11.952 0 0012 20.055a11.952 11.952 0 00-6.824-2.998 12.078 12.078 0 01.665-6.479L12 14z"></path>
                </svg>
                <div>
                  <p class="text-gray-700">{{ dentist.university }}</p>
                  <p class="text-gray-600 text-sm">Graduado en {{ dentist.graduation_year }}</p>
                </div>
              </div>
              
              <!-- Años de experiencia -->
              <div class="flex items-center" v-if="dentist.experience_years">
                <svg class="w-5 h-5 text-teal-600 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"></path>
                </svg>
                <p class="text-gray-700">{{ dentist.experience_years }} años de experiencia</p>
              </div>
              
              <!-- Registro profesional -->
              <div class="flex items-center" v-if="dentist.registration_number">
                <svg class="w-5 h-5 text-teal-600 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"></path>
                </svg>
                <p class="text-gray-700">Registro profesional: {{ dentist.registration_number }}</p>
              </div>
              
              <!-- Experiencia profesional -->
              <div v-if="dentist.professional_experience" class="mt-4">
                <h3 class="text-sm font-medium text-gray-700 mb-2">Experiencia profesional</h3>
                <p class="text-gray-700 whitespace-pre-line">{{ dentist.professional_experience }}</p>
              </div>
            </div>
          </div>
        </div>
        
        <!-- Segunda fila de tarjetas -->
        <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
          <!-- Servicios ofrecidos -->
          <div class="bg-gray-50 rounded-lg p-6">
            <h2 class="text-xl font-semibold text-gray-900 mb-4">Servicios ofrecidos</h2>
            
            <div v-if="dentist.services_list && dentist.services_list.length > 0" class="flex flex-wrap gap-2">
              <span 
                v-for="service in dentist.services_list" 
                :key="service" 
                class="px-3 py-1 bg-teal-100 text-teal-800 rounded-full text-sm"
              >
                {{ service }}
              </span>            
            </div>
            <p v-else class="text-gray-500 italic">No se han especificado servicios</p>          
          </div>
          
          <!-- Seguros aceptados -->
          <div class="bg-gray-50 rounded-lg p-6">
            <h2 class="text-xl font-semibold text-gray-900 mb-4">Seguros aceptados</h2>
            
            <div v-if="dentist.insurance_networks && dentist.insurance_networks.length > 0">
              <div class="flex flex-wrap gap-2">
                <span 
                  v-for="insurance in dentist.insurance_networks" 
                  :key="insurance" 
                  class="px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-sm"
                >
                  {{ insurance }}
                </span>              
              </div>
              <p v-else-if="dentist.insurance_accepted" class="text-gray-700">{{ dentist.insurance_accepted }}</p>              
              <p v-else class="text-gray-700">Acepta seguros (contacte para más información)</p>            
            </div>
            <p v-else class="text-gray-500 italic">No acepta seguros</p>          
          </div>
        </div>
        
        <!-- Tercera fila de tarjetas -->
        <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
          <!-- Idiomas -->
          <div class="bg-gray-50 rounded-lg p-6">
            <h2 class="text-xl font-semibold text-gray-900 mb-4">Idiomas</h2>            
            
            <div v-if="dentist.languages && dentist.languages.length > 0" class="flex flex-wrap gap-2">
              <span 
                v-for="language in dentist.languages" 
                :key="language" 
                class="px-3 py-1 bg-purple-100 text-purple-800 rounded-full text-sm"
              >
                {{ language }}
              </span>            
            </div>
            <p v-else class="text-gray-500 italic">No se han especificado idiomas</p>          
          </div>
          
          <!-- Horarios -->
          <div class="bg-gray-50 rounded-lg p-6">
            <h2 class="text-xl font-semibold text-gray-900 mb-4">Horarios de atención</h2>            
            
            <div v-if="dentist.office_hours" class="space-y-2">
              <div 
                v-for="(hours, day) in dentist.office_hours" 
                :key="day" 
                class="flex justify-between"
              >
                <span class="font-medium">{{ translateDay(day) }}</span>                
                <span>{{ hours }}</span>              
              </div>            
            </div>
            <p v-else class="text-gray-500 italic">Horarios no disponibles</p>          
          </div>
        </div>
        
        <!-- Mapa con ubicación -->        
        <div v-if="dentist.latitude && dentist.longitude" class="mt-6">          
          <div class="bg-gray-50 rounded-lg p-6">            
            <h2 class="text-xl font-semibold text-gray-900 mb-4">Ubicación</h2>            
            <div class="h-64 w-full rounded-lg overflow-hidden">              
              <MapView                
                :markers="[mapMarker]"                
                :center="mapCenter"                
                :zoom="15"                
                :show-info-window="true"              
              />            
            </div>          
          </div>        
        </div>
      </div>
    </div>
  </div>
</template>

<script lang="ts">
import { defineComponent, ref, computed, onMounted } from 'vue';
import { useRoute, useRouter } from 'vue-router';
import { useAuth } from '../../composables/useAuth';
import DirectoryService from '../../services/DirectoryService';
import { DentistProfile } from '../../types/dentist';
import { MapMarker } from '../../types/directory';
import MapView from '../../components/directory/MapView.vue';

export default defineComponent({
  name: 'DentistDetailView',
  
  components: {
    MapView
  },
  
  setup() {
    const route = useRoute();
    const router = useRouter();
    const { isAuthenticated } = useAuth();
    
    const dentist = ref<DentistProfile | null>(null);
    const loading = ref(true);
    const error = ref<string | null>(null);
    const isFavorite = ref(false);
    const favoriteLoading = ref(false);
    
    // Cargar perfil del dentista
    const loadDentistProfile = async () => {
      loading.value = true;
      error.value = null;
      
      try {
        const dentistId = parseInt(route.params.id as string);
        if (isNaN(dentistId)) {
          throw new Error('ID de dentista inválido');
        }
        
        const profile = await DirectoryService.getDentistProfile(dentistId);
        dentist.value = profile;
        
        // Verificar si es favorito para usuarios autenticados
        if (isAuthenticated.value) {
          const favorites = await DirectoryService.getFavorites();
          isFavorite.value = favorites.some(f => f.id === dentistId);
        }
      } catch (err) {
        console.error('Error al cargar perfil del dentista:', err);
        error.value = 'No se pudo cargar el perfil del dentista. Por favor, inténtalo de nuevo.';
      } finally {
        loading.value = false;
      }
    };
    
    // Alternar favorito
    const toggleFavorite = async () => {
      if (!isAuthenticated.value) {
        router.push({ name: 'login', query: { redirect: route.fullPath } });
        return;
      }
      
      if (!dentist.value) return;
      
      favoriteLoading.value = true;
      
      try {
        const response = await DirectoryService.toggleFavorite(dentist.value.id!);
        isFavorite.value = response.isFavorite;
      } catch (err) {
        console.error('Error al alternar favorito:', err);
      } finally {
        favoriteLoading.value = false;
      }
    };
    
    // Manejar error de carga de imagen
    const handleImageError = (event: Event) => {
      const target = event.target as HTMLImageElement;
      target.src = '/images/default-profile.jpg';
    };
    
    // Traducir día de la semana
    const translateDay = (day: string): string => {
      const days: Record<string, string> = {
        monday: 'Lunes',
        tuesday: 'Martes',
        wednesday: 'Miércoles',
        thursday: 'Jueves',
        friday: 'Viernes',
        saturday: 'Sábado',
        sunday: 'Domingo'
      };
      
      return days[day.toLowerCase()] || day;
    };
    
    // Obtener ícono de red social
    const getSocialIcon = (platform: string) => {
      // Aquí se podrían implementar íconos SVG para cada plataforma
      // O utilizar una librería de íconos como Font Awesome
      return 'div'; // Por defecto, retornamos un div
    };
    
    // Computar centro del mapa
    const mapCenter = computed(() => {
      if (dentist.value && dentist.value.latitude && dentist.value.longitude) {
        return {
          lat: dentist.value.latitude,
          lng: dentist.value.longitude
        };
      }
      
      // Centro por defecto (Ciudad de México)
      return { lat: 19.4326, lng: -99.1332 };
    });
    
    // Crear marcador para el mapa
    const mapMarker = computed<MapMarker>(() => {
      if (dentist.value && dentist.value.latitude && dentist.value.longitude) {
        return {
          id: dentist.value.id!,
          lat: dentist.value.latitude,
          lng: dentist.value.longitude,
          name: dentist.value.user?.name || '',
          specialty: dentist.value.specialty,
          office_address: dentist.value.office_address,
          city: dentist.value.city,
          state: dentist.value.state,
          profile_image: dentist.value.profile_image
        };
      }
      
      return {
        id: 0,
        lat: 19.4326,
        lng: -99.1332,
        name: ''
      };
    });
    
    // Cargar perfil al montar el componente
    onMounted(() => {
      loadDentistProfile();
    });
    
    return {
      dentist,
      loading,
      error,
      isAuthenticated,
      isFavorite,
      favoriteLoading,
      loadDentistProfile,
      toggleFavorite,
      handleImageError,
      translateDay,
      getSocialIcon,
      mapCenter,
      mapMarker
    };
  }
});
</script>
