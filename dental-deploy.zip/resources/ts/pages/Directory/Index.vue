<template>
  <div class="container mx-auto px-4 py-8">
    <h1 class="text-3xl font-bold text-gray-900 mb-6">Directorio de Dentistas</h1>
    
    <!-- Vista modos y barra de acciones -->
    <div class="flex justify-between items-center mb-6">
      <!-- Selector de modo de visualización -->
      <div class="flex items-center space-x-3">
        <button
          @click="directoryState.viewMode = 'grid'"
          class="p-2 rounded-md"
          :class="directoryState.viewMode === 'grid' ? 'bg-teal-100 text-teal-700' : 'bg-gray-100 text-gray-600'"
        >
          <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2V6zM14 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V6zM4 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2v-2zM14 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z" />
          </svg>
        </button>
        <button
          @click="directoryState.viewMode = 'list'"
          class="p-2 rounded-md"
          :class="directoryState.viewMode === 'list' ? 'bg-teal-100 text-teal-700' : 'bg-gray-100 text-gray-600'"
        >
          <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 10h16M4 14h16M4 18h16" />
          </svg>
        </button>
        <button
          @click="directoryState.viewMode = 'map'"
          class="p-2 rounded-md"
          :class="directoryState.viewMode === 'map' ? 'bg-teal-100 text-teal-700' : 'bg-gray-100 text-gray-600'"
        >
          <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 20l-5.447-2.724A1 1 0 013 16.382V5.618a1 1 0 011.447-.894L9 7m0 13l6-3m-6 3V7m6 10l4.553 2.276A1 1 0 0021 18.382V7.618a1 1 0 00-.553-.894L15 4m0 13V4m0 0L9 7" />
          </svg>
        </button>
      </div>
      
      <!-- Botón de favoritos (solo para usuarios autenticados) -->
      <button
        v-if="isAuthenticated"
        @click="toggleFavoritesView"
        class="px-4 py-2 rounded-md"
        :class="showingFavorites ? 'bg-red-100 text-red-700' : 'bg-gray-100 text-gray-700'"
      >
        <span class="flex items-center">
          <svg class="w-5 h-5 mr-2" :class="showingFavorites ? 'text-red-500' : ''" fill="currentColor" viewBox="0 0 20 20">
            <path fill-rule="evenodd" d="M3.172 5.172a4 4 0 015.656 0L10 6.343l1.172-1.171a4 4 0 115.656 5.656L10 17.657l-6.828-6.829a4 4 0 010-5.656z" clip-rule="evenodd" />
          </svg>
          {{ showingFavorites ? 'Todos los dentistas' : 'Mis favoritos' }}
        </span>
      </button>
    </div>
    
    <div class="lg:flex lg:space-x-6">
      <!-- Filtros (solo visible en modo grid o lista) -->
      <div 
        v-if="directoryState.viewMode !== 'map'" 
        class="lg:w-1/4 mb-6 lg:mb-0"
      >
        <DirectoryFilters
          v-model:filters="directoryState.filters"
          :filter-options="directoryState.filterOptions"
          @apply-filters="loadDentists()"
        />
      </div>
      
      <!-- Contenido principal -->
      <div :class="directoryState.viewMode !== 'map' ? 'lg:w-3/4' : 'w-full'">
        <!-- Estado de carga -->
        <div v-if="directoryState.loading && !directoryState.profiles.length" class="bg-white rounded-lg shadow p-8 flex justify-center">
          <div class="inline-block animate-spin rounded-full h-8 w-8 border-4 border-teal-500 border-t-transparent"></div>
        </div>
        
        <!-- Mensaje de error -->
        <div v-else-if="directoryState.error" class="bg-white rounded-lg shadow p-8">
          <div class="text-red-500 text-center">
            <svg class="w-12 h-12 mx-auto mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
            </svg>
            <p class="text-lg">{{ directoryState.error }}</p>
            <button 
              @click="loadDentists()" 
              class="mt-4 px-4 py-2 bg-teal-600 text-white rounded-md hover:bg-teal-700"
            >
              Reintentar
            </button>
          </div>
        </div>
        
        <!-- Sin resultados -->
        <div v-else-if="!directoryState.profiles.length" class="bg-white rounded-lg shadow p-8">
          <div class="text-gray-500 text-center">
            <svg class="w-12 h-12 mx-auto mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
            </svg>
            <p class="text-lg">No se encontraron dentistas con los criterios seleccionados.</p>
            <button 
              @click="resetFilters()" 
              class="mt-4 px-4 py-2 bg-teal-600 text-white rounded-md hover:bg-teal-700"
            >
              Limpiar filtros
            </button>
          </div>
        </div>
        
        <!-- Vista de mapa -->
        <div v-else-if="directoryState.viewMode === 'map'" class="mb-6">
          <MapView 
            :markers="getMapMarkers()"
            :center="directoryState.mapCenter"
            :zoom="directoryState.mapZoom"
            :loading="directoryState.loading"
            @marker-click="handleMarkerClick"
            @view-profile="viewDentistProfile"
            @bounds-changed="handleBoundsChanged"
          />
        </div>
        
        <!-- Vista de grid -->
        <div v-else-if="directoryState.viewMode === 'grid'" class="mb-6">
          <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <DentistCard
              v-for="dentist in directoryState.profiles"
              :key="dentist.id"
              :dentist="dentist"
              :favorited="directoryState.favorites.includes(dentist.id)"
              :show-favorite-button="isAuthenticated"
              @favorite-toggled="handleFavoriteToggled"
              @view-profile="viewDentistProfile"
            />
          </div>
        </div>
        
        <!-- Vista de lista -->
        <div v-else class="mb-6">
          <div class="space-y-4">
            <div
              v-for="dentist in directoryState.profiles"
              :key="dentist.id"
              class="bg-white rounded-lg shadow-md overflow-hidden p-4 hover:shadow-lg transition-shadow flex flex-col md:flex-row"
            >
              <!-- Imagen de perfil -->
              <div class="flex-shrink-0 md:mr-4 mb-4 md:mb-0 md:w-24">
                <div class="h-24 w-24 mx-auto md:mx-0 rounded-full overflow-hidden border-2 border-gray-200">
                  <img
                    :src="dentist.profile_image || '/images/default-profile.jpg'"
                    :alt="dentist.user?.name"
                    class="h-full w-full object-cover"
                  />
                </div>
              </div>
              
              <!-- Información principal -->
              <div class="flex-grow">
                <div class="flex justify-between items-start">
                  <div>
                    <h3 class="text-lg font-bold text-gray-900">{{ dentist.user?.name }}</h3>
                    <p class="text-sm text-gray-600 mb-1" v-if="dentist.specialty">{{ dentist.specialty }}</p>
                    
                    <!-- Calificación -->
                    <div class="flex items-center mb-2">
                      <div class="flex">
                        <template v-for="i in 5" :key="i">
                          <svg
                            class="w-4 h-4"
                            :class="i <= Math.round(dentist.rating || 0) ? 'text-yellow-400' : 'text-gray-300'"
                            fill="currentColor"
                            viewBox="0 0 20 20"
                          >
                            <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                          </svg>
                        </template>
                      </div>
                      <span class="ml-1 text-sm text-gray-600">
                        {{ dentist.rating ? dentist.rating.toFixed(1) : 'Sin calificaciones' }}
                      </span>
                    </div>
                  </div>
                  
                  <!-- Botón de favorito -->
                  <button
                    v-if="isAuthenticated"
                    type="button"
                    @click="toggleFavorite(dentist.id)"
                    :disabled="directoryState.favoritesLoading"
                    class="p-1 rounded-full hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-teal-500"
                  >
                    <svg
                      class="w-6 h-6"
                      :class="directoryState.favorites.includes(dentist.id) ? 'text-red-500 fill-current' : 'text-gray-400'"
                      fill="none"
                      stroke="currentColor"
                      viewBox="0 0 24 24"
                    >
                      <path
                        stroke-linecap="round"
                        stroke-linejoin="round"
                        stroke-width="2"
                        d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z"
                      ></path>
                    </svg>
                  </button>
                </div>
                
                <div class="flex flex-wrap md:items-center mt-2 text-sm text-gray-600">
                  <!-- Ubicación -->
                  <div class="mr-4 mb-2 flex items-center">
                    <svg class="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1114.142 0z" />
                      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
                    </svg>
                    {{ dentist.city }}, {{ dentist.state }}
                  </div>
                  
                  <!-- Años de experiencia -->
                  <div class="mr-4 mb-2 flex items-center" v-if="dentist.experience_years">
                    <svg class="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                    {{ dentist.experience_years }} años
                  </div>
                </div>
                
                <!-- Servicios (mostrar solo algunos) -->
                <div class="flex flex-wrap mt-3" v-if="dentist.services_list && dentist.services_list.length">
                  <span
                    v-for="(service, index) in dentist.services_list.slice(0, 3)"
                    :key="index"
                    class="mr-2 mb-2 inline-flex items-center px-2 py-1 rounded text-xs font-medium bg-teal-100 text-teal-800"
                  >
                    {{ service }}
                  </span>
                  <span
                    v-if="dentist.services_list.length > 3"
                    class="mr-2 mb-2 inline-flex items-center px-2 py-1 rounded text-xs font-medium bg-gray-100 text-gray-800"
                  >
                    +{{ dentist.services_list.length - 3 }} más
                  </span>
                </div>
                
                <!-- Botones de acción -->
                <div class="mt-4 flex justify-end">
                  <button
                    @click="viewDentistProfile(dentist)"
                    class="px-4 py-2 bg-teal-600 text-white text-sm font-medium rounded hover:bg-teal-700 focus:outline-none focus:ring-2 focus:ring-teal-500"
                  >
                    Ver perfil
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    
    <!-- Paginación -->
    <div v-if="directoryState.profiles.length && directoryState.lastPage > 1" class="mt-8 flex justify-center">
      <div class="flex space-x-1">
        <button
          @click="changePage(directoryState.currentPage - 1)"
          :disabled="directoryState.currentPage === 1"
          class="px-4 py-2 rounded-md"
          :class="directoryState.currentPage === 1 ? 'bg-gray-100 text-gray-400 cursor-not-allowed' : 'bg-gray-200 text-gray-700 hover:bg-gray-300'"
        >
          <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7" />
          </svg>
        </button>
        
        <template v-for="page in getPageNumbers()" :key="page">
          <button
            v-if="page !== '...'"
            @click="changePage(page)"
            :class="page === directoryState.currentPage 
              ? 'bg-teal-600 text-white' 
              : 'bg-gray-200 text-gray-700 hover:bg-gray-300'"
            class="px-4 py-2 rounded-md"
          >
            {{ page }}
          </button>
          <span v-else class="px-4 py-2 text-gray-500">...</span>
        </template>
        
        <button
          @click="changePage(directoryState.currentPage + 1)"
          :disabled="directoryState.currentPage === directoryState.lastPage"
          class="px-4 py-2 rounded-md"
          :class="directoryState.currentPage === directoryState.lastPage ? 'bg-gray-100 text-gray-400 cursor-not-allowed' : 'bg-gray-200 text-gray-700 hover:bg-gray-300'"
        >
          <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7" />
          </svg>
        </button>
      </div>
    </div>
  </div>
</template>
<script lang="ts">
import { defineComponent, onMounted, reactive, computed, ref, watch, nextTick } from 'vue';
import { useRouter } from 'vue-router';
import DirectoryFilters from '../../components/directory/DirectoryFilters.vue';
import DentistCard from '../../components/directory/DentistCard.vue';
import MapView from '../../components/directory/MapView.vue';
import DirectoryService from '../../services/DirectoryService';
import { DirectoryState, MapMarker, DirectoryFilters as DirectoryFiltersType } from '../../types/directory';
import { DentistProfile } from '../../types/dentist';
import { useAuth } from '../../composables/useAuth';

export default defineComponent({
  name: 'DirectoryIndex',
  
  components: {
    DirectoryFilters,
    DentistCard,
    MapView
  },
  
  setup() {
    const router = useRouter();
    const { isAuthenticated } = useAuth();
    const observer = ref<IntersectionObserver | null>(null);
    const showingFavorites = ref(false);
    
    // Estado del directorio
    const directoryState = reactive<DirectoryState>({
      profiles: [],
      favorites: [],
      filterOptions: null,
      loading: false,
      error: null,
      favoritesLoading: false,
      currentPage: 1,
      lastPage: 1,
      totalResults: 0,
      infiniteLoading: false,
      viewMode: 'grid',
      mapCenter: { lat: 19.4326, lng: -99.1332 }, // Ciudad de México por defecto
      mapZoom: 12,
      filters: {
        search: '',
        specialty: '',
        services: [],
        location: '',
        languages: [],
        minExperience: 0,
        sortBy: 'rating',
        sortDir: 'desc',
        perPage: 12,
        page: 1
      }
    });
    
    // Cargar dentistas y opciones de filtros
    const loadDentists = async (resetPagination = true) => {
      if (resetPagination) {
        directoryState.currentPage = 1;
        directoryState.profiles = [];
      }
      
      directoryState.loading = true;
      directoryState.error = null;
      
      try {
        // Preparar los parámetros según el estado actual
        const params = {
          ...directoryState.filters,
          page: directoryState.currentPage,
          favorites_only: showingFavorites.value
        };
        
        // Solicitar dentistas
        const response = await DirectoryService.getDentists(params);
        
        if (response.data) {
          // Si es primera página o resetPagination, reemplazar la lista
          if (directoryState.currentPage === 1 || resetPagination) {
            directoryState.profiles = response.data;
          } else {
            // Añadir a la lista existente (para scroll infinito)
            directoryState.profiles = [...directoryState.profiles, ...response.data];
          }
          
          directoryState.currentPage = response.current_page;
          directoryState.lastPage = response.last_page;
          directoryState.totalResults = response.total;
        }
        
        // Cargar favoritos si el usuario está autenticado
        if (isAuthenticated.value && !directoryState.favorites.length) {
          loadFavorites();
        }
      } catch (error) {
        console.error('Error al cargar dentistas:', error);
        directoryState.error = 'No se pudieron cargar los dentistas. Por favor, inténtalo de nuevo.';
      } finally {
        directoryState.loading = false;
        directoryState.infiniteLoading = false;
      }
    };
    
    // Cargar opciones de filtros
    const loadFilterOptions = async () => {
      try {
        const options = await DirectoryService.getFilterOptions();
        directoryState.filterOptions = options;
      } catch (error) {
        console.error('Error al cargar opciones de filtros:', error);
      }
    };
    
    // Cargar favoritos del usuario
    const loadFavorites = async () => {
      if (!isAuthenticated.value) return;
      
      try {
        directoryState.favoritesLoading = true;
        const favorites = await DirectoryService.getFavorites();
        
        if (favorites && Array.isArray(favorites)) {
          directoryState.favorites = favorites.map(f => f.id);
        }
      } catch (error) {
        console.error('Error al cargar favoritos:', error);
      } finally {
        directoryState.favoritesLoading = false;
      }
    };
    
    // Alternar favorito
    const toggleFavorite = async (dentistId: number) => {
      if (!isAuthenticated.value) {
        // Redirigir a login si no está autenticado
        router.push({ name: 'login', query: { redirect: router.currentRoute.value.fullPath } });
        return;
      }
      
      try {
        const response = await DirectoryService.toggleFavorite(dentistId);
        
        // Actualizar estado local
        if (response.isFavorite) {
          if (!directoryState.favorites.includes(dentistId)) {
            directoryState.favorites.push(dentistId);
          }
        } else {
          directoryState.favorites = directoryState.favorites.filter(id => id !== dentistId);
          
          // Si estamos viendo solo favoritos, recargar para eliminar el dentista de la vista
          if (showingFavorites.value) {
            loadDentists();
          }
        }
      } catch (error) {
        console.error('Error al alternar favorito:', error);
      }
    };
    
    // Manejar cambio de favorito desde el componente de tarjeta
    const handleFavoriteToggled = ({ dentistId, isFavorite }: { dentistId: number, isFavorite: boolean }) => {
      if (isFavorite) {
        if (!directoryState.favorites.includes(dentistId)) {
          directoryState.favorites.push(dentistId);
        }
      } else {
        directoryState.favorites = directoryState.favorites.filter(id => id !== dentistId);
        
        // Si estamos viendo solo favoritos, recargar para eliminar el dentista de la vista
        if (showingFavorites.value) {
          loadDentists();
        }
      }
    };
    
    // Ver perfil de dentista
    const viewDentistProfile = (dentist: DentistProfile) => {
      router.push({ 
        name: 'dentist-profile', 
        params: { id: dentist.id },
      });
    };
    
    // Alternar vista de favoritos
    const toggleFavoritesView = () => {
      showingFavorites.value = !showingFavorites.value;
      loadDentists();
    };
    
    // Reset filtros
    const resetFilters = () => {
      directoryState.filters = {
        search: '',
        specialty: '',
        services: [],
        location: '',
        languages: [],
        minExperience: 0,
        sortBy: 'rating',
        sortDir: 'desc',
        perPage: 12,
        page: 1
      };
      loadDentists();
    };
    
    // Cambiar página
    const changePage = (page: number) => {
      if (page < 1 || page > directoryState.lastPage) return;
      
      directoryState.currentPage = page;
      directoryState.filters.page = page;
      
      // En modo mapa no hacemos scroll hacia arriba
      if (directoryState.viewMode !== 'map') {
        window.scrollTo({ top: 0, behavior: 'smooth' });
      }
      
      loadDentists(false);
    };
    
    // Obtener números de página para paginador
    const getPageNumbers = () => {
      const { currentPage, lastPage } = directoryState;
      const delta = 2; // Número de páginas a mostrar a cada lado de la actual
      const range: (number | string)[] = [];
      
      for (let i = 1; i <= lastPage; i++) {
        if (
          i === 1 ||
          i === lastPage ||
          (i >= currentPage - delta && i <= currentPage + delta)
        ) {
          range.push(i);
        } else if (i === currentPage - delta - 1 || i === currentPage + delta + 1) {
          range.push('...');
        }
      }
      
      return range;
    };
    
    // Obtener marcadores para el mapa
    const getMapMarkers = (): MapMarker[] => {
      return directoryState.profiles
        .filter(profile => profile.latitude && profile.longitude)
        .map(profile => ({
          id: profile.id,
          lat: profile.latitude!,
          lng: profile.longitude!,
          name: profile.user?.name || '',
          ...profile // Incluir todos los datos del perfil para mostrar en infowindow
        }));
    };
    
    // Manejar clic en marcador del mapa
    const handleMarkerClick = (dentistId: number) => {
      // Si estamos en el modo de mapa, no hacemos nada más que mostrar la info
      // La lógica adicional para mostrar detalles se maneja en el componente MapView
    };
    
    // Manejar cambio de límites del mapa
    const handleBoundsChanged = (bounds: { ne: { lat: number, lng: number }, sw: { lat: number, lng: number } }) => {
      if (directoryState.viewMode === 'map') {
        // Opcional: cargar dentistas dentro de estos límites geográficos
        // En este momento, usaremos esto solo para guardar la posición del mapa
      }
    };
    
    // Configurar scroll infinito
    const setupInfiniteScroll = () => {
      if (observer.value) {
        observer.value.disconnect();
      }
      
      observer.value = new IntersectionObserver(entries => {
        if (entries[0].isIntersecting && !directoryState.loading && directoryState.currentPage < directoryState.lastPage) {
          directoryState.infiniteLoading = true;
          directoryState.currentPage++;
          loadDentists(false);
        }
      });
      
      // Observar un elemento al final de la lista
      const sentinel = document.querySelector('.infinite-scroll-sentinel');
      if (sentinel) {
        observer.value.observe(sentinel);
      }
    };
    
    // Observar cambios en el modo de vista
    watch(() => directoryState.viewMode, (newMode) => {
      // Si cambiamos a vista de mapa y no hay coordenadas, usar filtros de ubicación
      if (newMode === 'map') {
        // Aquí podríamos ajustar el centro del mapa basado en los resultados o filtros
      }
    });
    
    // Montar componente
    onMounted(async () => {
      // Cargar opciones de filtros
      await loadFilterOptions();
      
      // Cargar dentistas
      await loadDentists();
      
      // Configurar scroll infinito
      nextTick(() => {
        setupInfiniteScroll();
      });
    });
    
    return {
      directoryState,
      isAuthenticated,
      showingFavorites,
      loadDentists,
      resetFilters,
      changePage,
      getPageNumbers,
      getMapMarkers,
      handleMarkerClick,
      handleBoundsChanged,
      toggleFavorite,
      viewDentistProfile,
      toggleFavoritesView,
      handleFavoriteToggled
    };
  }
});
</script>
