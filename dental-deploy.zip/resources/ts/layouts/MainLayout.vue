<template>
  <div class="min-h-screen bg-gray-50">
    <!-- Barra de navegación -->
    <nav class="bg-white shadow-sm">
      <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="flex justify-between h-16">
          <div class="flex">
            <div class="flex-shrink-0 flex items-center">
              <!-- Logo -->
              <router-link to="/" class="text-xl font-bold text-blue-800">
                Comunidad Odontológica
              </router-link>
            </div>
            <div class="hidden sm:ml-6 sm:flex sm:space-x-8">
              <!-- Enlaces de navegación -->
              <router-link 
                to="/" 
                class="border-transparent text-gray-500 hover:border-gray-300 hover:text-gray-700 inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium"
                :class="{ 'border-blue-500 text-gray-900': $route.name === 'home' }"
              >
                Inicio
              </router-link>
              <a 
                href="#" 
                class="border-transparent text-gray-500 hover:border-gray-300 hover:text-gray-700 inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium"
              >
                Comunidad
              </a>
              <a 
                href="#" 
                class="border-transparent text-gray-500 hover:border-gray-300 hover:text-gray-700 inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium"
              >
                Recursos
              </a>
              <router-link 
                to="/directory" 
                class="border-transparent text-gray-500 hover:border-gray-300 hover:text-gray-700 inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium"
                :class="{ 'border-blue-500 text-gray-900': $route.path.startsWith('/directory') }"
              >
                Directorio de Dentistas
              </router-link>
              <a 
                href="#" 
                class="border-transparent text-gray-500 hover:border-gray-300 hover:text-gray-700 inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium"
              >
                Eventos
              </a>
            </div>
          </div>
          <div class="hidden sm:ml-6 sm:flex sm:items-center">
            <!-- Botones de acceso -->
            <template v-if="!isAuthenticated">
              <router-link 
                to="/login" 
                class="text-gray-500 hover:text-gray-700 px-3 py-2 rounded-md text-sm font-medium"
              >
                Iniciar sesión
              </router-link>
              <router-link 
                to="/register" 
                class="bg-blue-600 hover:bg-blue-700 text-white px-3 py-2 rounded-md text-sm font-medium"
              >
                Registrarse
              </router-link>
            </template>
            <!-- Menú de usuario -->
            <div v-else class="ml-3 relative">
              <div>
                <button 
                  @click="toggleDropdown" 
                  class="bg-white rounded-full flex text-sm focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                >
                  <span class="sr-only">Abrir menú de usuario</span>
                  <div class="h-8 w-8 rounded-full bg-blue-200 flex items-center justify-center text-blue-600">
                    {{ userInitials }}
                  </div>
                </button>
              </div>
              <!-- Menú desplegable -->
              <div 
                v-if="isDropdownOpen" 
                class="origin-top-right absolute right-0 mt-2 w-48 rounded-md shadow-lg py-1 bg-white ring-1 ring-black ring-opacity-5"
              >
                <router-link 
                  to="/dashboard" 
                  class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                >
                  Mi perfil
                </router-link>
                <router-link 
                  to="/dashboard/settings" 
                  class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                >
                  Configuración
                </router-link>
                <button 
                  @click="logout" 
                  class="block w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                >
                  Cerrar sesión
                </button>
              </div>
            </div>
          </div>
          
          <!-- Menú móvil -->
          <div class="-mr-2 flex items-center sm:hidden">
            <button 
              @click="toggleMobileMenu" 
              class="inline-flex items-center justify-center p-2 rounded-md text-gray-400 hover:text-gray-500 hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-inset focus:ring-blue-500"
            >
              <span class="sr-only">Abrir menú principal</span>
              <!-- Icono de hamburguesa -->
              <svg 
                v-if="!isMobileMenuOpen" 
                class="block h-6 w-6" 
                xmlns="http://www.w3.org/2000/svg" 
                fill="none" 
                viewBox="0 0 24 24" 
                stroke="currentColor" 
                aria-hidden="true"
              >
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16" />
              </svg>
              <!-- Icono X -->
              <svg 
                v-else 
                class="block h-6 w-6" 
                xmlns="http://www.w3.org/2000/svg" 
                fill="none" 
                viewBox="0 0 24 24" 
                stroke="currentColor" 
                aria-hidden="true"
              >
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>
        </div>
      </div>
      
      <!-- Menú móvil -->
      <div v-if="isMobileMenuOpen" class="sm:hidden">
        <div class="pt-2 pb-3 space-y-1">
          <router-link 
            to="/" 
            class="block pl-3 pr-4 py-2 border-l-4 text-base font-medium"
            :class="{ 'border-blue-500 text-blue-700 bg-blue-50': $route.name === 'home', 'border-transparent text-gray-600 hover:bg-gray-50 hover:border-gray-300 hover:text-gray-800': $route.name !== 'home' }"
          >
            Inicio
          </router-link>
          <a 
            href="#" 
            class="border-transparent text-gray-600 hover:bg-gray-50 hover:border-gray-300 hover:text-gray-800 block pl-3 pr-4 py-2 border-l-4 text-base font-medium"
          >
            Comunidad
          </a>
          <a 
            href="#" 
            class="border-transparent text-gray-600 hover:bg-gray-50 hover:border-gray-300 hover:text-gray-800 block pl-3 pr-4 py-2 border-l-4 text-base font-medium"
          >
            Recursos
          </a>
          <router-link 
            to="/directory" 
            class="block pl-3 pr-4 py-2 border-l-4 text-base font-medium"
            :class="$route.path.startsWith('/directory') ? 'bg-blue-50 border-blue-500 text-blue-700' : 'border-transparent text-gray-600 hover:bg-gray-50 hover:border-gray-300 hover:text-gray-800'"
          >
            Directorio de Dentistas
          </router-link>
          <a 
            href="#" 
            class="border-transparent text-gray-600 hover:bg-gray-50 hover:border-gray-300 hover:text-gray-800 block pl-3 pr-4 py-2 border-l-4 text-base font-medium"
          >
            Eventos
          </a>
        </div>
        <div class="pt-4 pb-3 border-t border-gray-200">
          <div v-if="isAuthenticated" class="flex items-center px-4">
            <div class="flex-shrink-0">
              <div class="h-10 w-10 rounded-full bg-blue-200 flex items-center justify-center text-blue-600">
                {{ userInitials }}
              </div>
            </div>
            <div class="ml-3">
              <div class="text-base font-medium text-gray-800">{{ userName }}</div>
              <div class="text-sm font-medium text-gray-500">{{ userEmail }}</div>
            </div>
          </div>
          <div class="mt-3 space-y-1">
            <template v-if="isAuthenticated">
              <router-link 
                to="/dashboard" 
                class="block px-4 py-2 text-base font-medium text-gray-500 hover:text-gray-800 hover:bg-gray-100"
              >
                Mi perfil
              </router-link>
              <router-link 
                to="/dashboard/settings" 
                class="block px-4 py-2 text-base font-medium text-gray-500 hover:text-gray-800 hover:bg-gray-100"
              >
                Configuración
              </router-link>
              <button 
                @click="logout" 
                class="block w-full text-left px-4 py-2 text-base font-medium text-gray-500 hover:text-gray-800 hover:bg-gray-100"
              >
                Cerrar sesión
              </button>
            </template>
            <template v-else>
              <router-link 
                to="/login" 
                class="block px-4 py-2 text-base font-medium text-gray-500 hover:text-gray-800 hover:bg-gray-100"
              >
                Iniciar sesión
              </router-link>
              <router-link 
                to="/register" 
                class="block px-4 py-2 text-base font-medium text-gray-500 hover:text-gray-800 hover:bg-gray-100"
              >
                Registrarse
              </router-link>
            </template>
          </div>
        </div>
      </div>
    </nav>
    
    <!-- Contenido principal -->
    <main>
      <slot></slot>
    </main>
    
    <!-- Pie de página -->
    <footer class="bg-white mt-12 border-t border-gray-200">
      <div class="max-w-7xl mx-auto py-12 px-4 overflow-hidden sm:px-6 lg:px-8">
        <nav class="-mx-5 -my-2 flex flex-wrap justify-center" aria-label="Footer">
          <div class="px-5 py-2">
            <a href="#" class="text-base text-gray-500 hover:text-gray-900">Acerca de</a>
          </div>
          <div class="px-5 py-2">
            <a href="#" class="text-base text-gray-500 hover:text-gray-900">Blog</a>
          </div>
          <div class="px-5 py-2">
            <a href="#" class="text-base text-gray-500 hover:text-gray-900">Contacto</a>
          </div>
          <div class="px-5 py-2">
            <a href="#" class="text-base text-gray-500 hover:text-gray-900">Términos y condiciones</a>
          </div>
          <div class="px-5 py-2">
            <a href="#" class="text-base text-gray-500 hover:text-gray-900">Política de privacidad</a>
          </div>
        </nav>
        <p class="mt-8 text-center text-base text-gray-500">
          &copy; {{ new Date().getFullYear() }} Comunidad Odontológica. Todos los derechos reservados.
        </p>
      </div>
    </footer>
  </div>
</template>

<script lang="ts">
import { defineComponent, ref, computed } from 'vue'
import { useRouter } from 'vue-router'

export default defineComponent({
  name: 'MainLayout',
  setup() {
    const router = useRouter()
    
    // Estado para el menú desplegable del usuario
    const isDropdownOpen = ref(false)
    const isMobileMenuOpen = ref(false)
    
    // Estado de autenticación (se obtendrá de un store en una implementación real)
    const isAuthenticated = computed(() => {
      return localStorage.getItem('auth_token') !== null
    })
    
    // Datos del usuario (se obtendrían de un store en una implementación real)
    const userName = ref('Usuario Demo')
    const userEmail = ref('usuario@ejemplo.com')
    
    // Calcular iniciales del usuario para avatar
    const userInitials = computed(() => {
      if (!userName.value) return '?'
      return userName.value
        .split(' ')
        .map(name => name[0])
        .join('')
        .toUpperCase()
        .substring(0, 2)
    })
    
    // Alternar menú desplegable
    const toggleDropdown = () => {
      isDropdownOpen.value = !isDropdownOpen.value
    }
    
    // Alternar menú móvil
    const toggleMobileMenu = () => {
      isMobileMenuOpen.value = !isMobileMenuOpen.value
    }
    
    // Cerrar sesión
    const logout = async () => {
      try {
        // Llamar a API de logout
        await fetch('/logout', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]')?.getAttribute('content') || '',
          },
          credentials: 'same-origin'
        })
        
        // Eliminar token de localStorage
        localStorage.removeItem('auth_token')
        
        // Redireccionar a la página de inicio
        router.push('/')
      } catch (error) {
        console.error('Error en logout:', error)
      }
    }
    
    return {
      isAuthenticated,
      isDropdownOpen,
      isMobileMenuOpen,
      userName,
      userEmail,
      userInitials,
      toggleDropdown,
      toggleMobileMenu,
      logout
    }
  }
})
</script>
