import { createRouter, createWebHistory, RouteRecordRaw } from 'vue-router'
import { useAuthStore } from '../stores/auth'

// Importamos usando imports dinámicos para que TypeScript no tenga problemas
const Home = () => import('../pages/Home.vue')
const Login = () => import('../pages/auth/Login.vue')
const RegisterType = () => import('../pages/auth/RegisterType.vue')
const RegisterPatient = () => import('../pages/auth/RegisterPatient.vue')
const RegisterDentist = () => import('../pages/auth/RegisterDentist.vue')
const Dashboard = () => import('../pages/Dashboard/Index.vue')

// Áreas por rol
const Admin = () => import('../pages/Admin/Index.vue')
const Dentist = () => import('../pages/Dentist/Index.vue')
const Patient = () => import('../pages/Patient/Index.vue')

// Páginas del perfil del dentista
const DentistProfile = () => import('../pages/Dentist/Profile/Index.vue')
const DentistProfileEdit = () => import('../pages/Dentist/Profile/Edit.vue')
const DentistProfileDocuments = () => import('../pages/Dentist/Profile/Documents.vue')
const DentistProfileVerification = () => import('../pages/Dentist/Profile/Verification.vue')

// Páginas de administración para verificación de dentistas
const AdminVerification = () => import('../pages/Admin/Verification/Index.vue')
const AdminVerificationDetail = () => import('../pages/Admin/Verification/Detail.vue')

// Páginas del directorio público de dentistas
const DirectoryIndex = () => import('../pages/Directory/Index.vue')
const DirectoryDetail = () => import('../pages/Directory/DetailView.vue')

// Definición de rutas
const routes: Array<RouteRecordRaw> = [
  {
    path: '/',
    name: 'home',
    component: Home
  },
  {
    path: '/login',
    name: 'login',
    component: Login
  },
  {
    path: '/register',
    name: 'register',
    component: RegisterType
  },
  {
    path: '/register/patient',
    name: 'register-patient',
    component: RegisterPatient
  },
  {
    path: '/register/dentist',
    name: 'register-dentist',
    component: RegisterDentist
  },
  // Rutas protegidas que requieren autenticación
  {
    path: '/dashboard',
    name: 'dashboard',
    component: Dashboard,
    meta: { requiresAuth: true }
  },
  // Rutas para administradores
  {
    path: '/admin',
    name: 'admin',
    component: Admin,
    meta: { requiresAuth: true, role: 'admin' },
    children: [
      {
        path: 'verification',
        name: 'admin-verification',
        component: AdminVerification,
        meta: { requiresAuth: true, role: 'admin' }
      },
      {
        path: 'verification/:id',
        name: 'admin-verification-detail',
        component: AdminVerificationDetail,
        meta: { requiresAuth: true, role: 'admin' },
        props: true
      }
    ]
  },
  // Rutas para odontólogos
  {
    path: '/dentist',
    name: 'dentist',
    component: Dentist,
    meta: { requiresAuth: true, role: 'dentist' },
    children: [
      {
        path: 'profile',
        name: 'dentist-profile',
        component: DentistProfile,
        meta: { requiresAuth: true, role: 'dentist' }
      },
      {
        path: 'profile/edit',
        name: 'dentist-profile-edit',
        component: DentistProfileEdit,
        meta: { requiresAuth: true, role: 'dentist' }
      },
      {
        path: 'profile/documents',
        name: 'dentist-profile-documents',
        component: DentistProfileDocuments,
        meta: { requiresAuth: true, role: 'dentist' }
      },
      {
        path: 'profile/verification',
        name: 'dentist-profile-verification',
        component: DentistProfileVerification,
        meta: { requiresAuth: true, role: 'dentist' }
      }
    ]
  },
  
  // Directorio público de dentistas
  {
    path: '/directory',
    name: 'directory',
    component: DirectoryIndex
  },
  {
    path: '/directory/:id',
    name: 'dentist-profile',
    component: DirectoryDetail,
    props: true
  },
  
  // Ruta pública para ver perfiles de dentistas verificados (legacy)
  {
    path: '/dentist/:id/profile',
    name: 'public-dentist-profile',
    component: () => import('../pages/Public/DentistProfile.vue')
  },
  // Rutas para pacientes
  {
    path: '/patient',
    name: 'patient',
    component: Patient,
    meta: { requiresAuth: true, role: 'patient' }
  }
]

const router = createRouter({
  history: createWebHistory(),
  routes
})

// Middleware de autenticación y roles
router.beforeEach(async (to, from, next) => {
  // Verificar si la ruta requiere autenticación
  if (to.matched.some(record => record.meta.requiresAuth)) {
    // Comprobar si el usuario está autenticado
    const isAuthenticated = localStorage.getItem('auth_token')
    
    if (!isAuthenticated) {
      // Redirigir al login si no está autenticado
      next({ 
        name: 'login',
        query: { redirect: to.fullPath } // Para redirigir de vuelta después del login
      })
      return
    }
    
    // Verificar roles si la ruta los requiere
    if (to.meta.role) {
      const authStore = useAuthStore()
      
      // Asegurarse de que tenemos la información del usuario
      if (!authStore.user) {
        try {
          await authStore.getCurrentUser()
        } catch (error) {
          console.error('Error al obtener datos del usuario:', error)
          // Si hay error al obtener el usuario, limpiar auth y redirigir al login
          authStore.clearAuth()
          next({ name: 'login' })
          return
        }
      }
      
      // Verificar si el usuario tiene el rol requerido
      const userRole = authStore.user?.role
      const requiredRole = to.meta.role as string
      const isAdmin = userRole === 'admin'
      
      // Permitir acceso a administradores a cualquier área o verificar rol específico
      if (isAdmin || userRole === requiredRole) {
        next()
      } else {
        // Redirigir al dashboard si no tiene el rol adecuado
        next({ name: 'dashboard' })
      }
    } else {
      // La ruta sólo requiere autenticación, no un rol específico
      next()
    }
  } else {
    // Rutas públicas
    next()
  }
})

export default router
